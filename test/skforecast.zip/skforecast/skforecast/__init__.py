name = "skforecast"
__version__ = "0.15.0"
